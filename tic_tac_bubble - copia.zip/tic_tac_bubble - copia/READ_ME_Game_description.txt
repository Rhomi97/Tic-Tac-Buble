Game Description:
* Multiplayer Game (2 players on a single computer):
-Move your player from left to right with the right and left keyboards, blow bubbles with the up keyboard
-Switch from player to its player dog with space bar
-Move your player's dog from left to right with the right and left keyboards, and make the dog jump with the up keyboard
-Let the bubble float and burst the bubble with the dog once it reaches the square where you want to put your game token
(for player 1: X, and for player 2: 0)
If you burst the bubble on line or if the bubble is outside the game screen, you loose your chance to place your token where
you want.
Btw, don't blow the bubble too much or it may explode, therefore, you loose to place your token in your current turn.
When the tokens of a player form a straight line, its player wins
