import pygame
import sys
from random import randint

class Area():
  def __init__(self, x=0, y=0, width=10, height=10, color=None):
      self.rect = pygame.Rect(x, y, width, height) #rectángulo
      self.fill_color = color
  def color(self, new_color):
      self.fill_color = new_color
  def fill(self,mw):
      pygame.draw.rect(mw, self.fill_color, self.rect)
  def outline(self,mw, frame_color, thickness): #delimita un rectángulo existente
      pygame.draw.rect(mw, frame_color, self.rect, thickness)   
  def collidepoint(self, x, y):
      return self.rect.collidepoint(x, y)
      
  
class GameToken(Area):
  def set_text(self, text, isToken, fsize=180, text_color=(0, 0, 0)):
      self.image = pygame.font.SysFont('verdana', fsize).render(text, True, text_color)
      self.isToken = isToken
  def setToken(self, isToken):
      self.isToken = isToken
  def draw(self, mw, shift_x=0, shift_y=0):
      if self.isToken:
        self.fill(mw)
        mw.blit(self.image, (self.rect.x + shift_x, self.rect.y + shift_y))
      else:
        self.fill(mw)

class Player():
  def __init__(self, man, man2, dog, dog2, trianglePin, bubble1, bubble2, bubble3, bubble4, bubble5, x=0, y=600, x2=50,y2=750):
      self.rectPlyr = pygame.Rect(x, y, 50,200)
      self.imagePlyr = [pygame.image.load(man),pygame.image.load(man2)]
      self.rectDog = [pygame.Rect(x2, y2,100,50),pygame.Rect(x, y, 50, 100)]
      self.imageDog = [pygame.image.load(dog),pygame.image.load(dog2)]
      self.trianglePinRect = pygame.Rect(x+14, y+106, 35,35)
      self.trianglePinRect2 = pygame.Rect(x+25, y+25, 35,35)
      self.trianglePinImg = pygame.image.load(trianglePin)
      self.bubbles = [pygame.image.load(bubble1),pygame.image.load(bubble2),pygame.image.load(bubble3),pygame.image.load(bubble4),pygame.image.load(bubble5)]
      self.bubblesManRect = pygame.Rect(x+22, y+41, 5,5)
      self.bubblesManRectExpsn = pygame.Rect(x+22, y+41, 5,5) #bubblesrect expansion
      self.currMan = 0
      self.currBubble = 0
      self.isPined = False
      self.expandBubble = False
      self.floatinngBubbleRect = pygame.Rect(x+22-2, y+41-2, 5+3,5+3)
      self.floatinngBubble = 1
      self.isDog = False
      self.isFloating = False
      self.currDog = 0
      self.isPlayer = False
      #self.isThisCurr = False
  
  def changeMan(self):
      if self.currMan == 0:
          self.currMan = 1
      elif self.currMan == 1:
          self.currMan == 0
          
  def moveManRight(self):
        self.rectPlyr.x += 3
        self.trianglePinRect.x += 3
        self.bubblesManRect.x += 3
        self.bubblesManRectExpsn.x += 3

  def moveManLeft(self):
        self.rectPlyr.x -= 3
        self.trianglePinRect.x -= 3
        self.bubblesManRect.x -= 3
        self.bubblesManRectExpsn.x -= 3
  
  def moveDogRight(self):
        self.rectDog[0].x += 3
        self.rectDog[1].x += 3
        self.trianglePinRect2.x += 3
  
  def moveDogLeft(self):
        self.rectDog[0].x -= 3
        self.rectDog[1].x -= 3
        self.trianglePinRect2.x -= 3
        
  def moveDogUp(self):
        self.rectDog[0].y -= 5
        self.rectDog[1].y -= 5
        self.trianglePinRect2.y -= 5
        self.currDog = 1
        
  def dogFalling(self):
        self.rectDog[0].y += 3
        self.rectDog[1].y += 3
        self.trianglePinRect2.y += 3
        self.currDog = 0
        if self.rectDog[0].y >= 750:
            self.rectDog[0].y = 750
          
  def bubbleExpansion(self):
      if self.expandBubble:
          #mw.blit(self.bubbles[self.currBubble], (self.bubblesManRectExpsn.x,self.bubblesManRectExpsn.y))
          self.bubblesManRectExpsn.x -= 2
          self.bubblesManRectExpsn.y -= 2
          self.bubblesManRectExpsn.width += 3
          self.bubblesManRectExpsn.height += 3
          self.currBubble += 1
          if self.currBubble >= 4:
              self.expandBubble = False
      #else:
      #    self.bubblesManRectExpsn = pygame.Rect(self.bubblesManRect.x, self.bubblesManRect.y, 5,5)
          
          
  def drawMan(self,mw):
      mw.blit(self.imagePlyr[self.currMan], (self.rectPlyr.x, self.rectPlyr.y)) 
      #mw.blit(self.imagePlyr[1], (self.rectPlyr.x, self.rectPlyr.y))
      #mw.blit(self.bubbles[0], (self.bubblesManRect.x,self.bubblesManRect.y))
      if (not self.isDog) and self.isPlayer:
        mw.blit(self.trianglePinImg, (self.trianglePinRect.x,self.trianglePinRect.y))
      if self.expandBubble:
          mw.blit(self.bubbles[self.currBubble], (self.bubblesManRectExpsn.x,self.bubblesManRectExpsn.y))
          self.bubbleExpansion()
      if self.isDog and self.isFloating:
          self.bubbleFloating()
          mw.blit(self.bubbles[self.floatinngBubble], (self.floatinngBubbleRect.x,self.floatinngBubbleRect.y))
  
  def bubbleFloating(self):
      self.floatinngBubbleRect.y -= 3
  def drawDog(self,mw):
      mw.blit(self.imageDog[self.currDog],(self.rectDog[self.currDog].x, self.rectDog[self.currDog].y))
      if self.isDog and self.isPlayer:
          mw.blit(self.trianglePinImg, (self.trianglePinRect2.x,self.trianglePinRect2.y))
      
class Game():
    def __init__(self):
        pygame.init()
        self.screen_width = 600
        self.screen_height = 800
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.clock = pygame.time.Clock()
        self.back = (163, 3, 19)
        self.linesColor = (126, 235, 29)
        self.fontsColor = (255,255,255)
        self.board = []
        self.tokens_player1 = []
        self.tokens_player2 = []
        self.horizontal_lines = []
        self.vertical_lines = []
        self.player1Token = 'X'
        self.player2Token = '0'
        board_lines_size = 20
        board_lines_size2 = 600
        board_square_size = 200 #i'll use this for the board lines shift
        board_square_shft = board_lines_size + board_square_size
        y_start = 0
        #self.token1 = GameToken(0, 0,180,180, self.back)
        #self.token1.set_text('X',1,180,self.linesColor)
        for i in range(3):
            x_start = 0
            boardrow = []
            tokens1 = []
            tokens2 = []
            for j in range(3):
                boardrow.append(Area(x_start,y_start,board_square_size,board_square_size,self.back))
                tokens1.append(GameToken(x_start,y_start,150,150,self.back))
                tokens1[j].set_text(self.player1Token,False,120,self.linesColor)
                tokens2.append(GameToken(x_start,y_start,150,150,self.back))
                tokens2[j].set_text(self.player2Token,False,120,self.linesColor)
                x_start += board_square_shft
            y_start += board_square_shft
            self.board.append(boardrow)
            self.tokens_player1.append(tokens1)
            self.tokens_player2.append(tokens2)
        y_start = 0
        x_start = 0
        for i in range(2):
            x_start += board_square_size
            self.vertical_lines.append(Area(x_start,y_start,board_lines_size,board_lines_size2,self.linesColor))
        x_start = 0
        for i in range(3):
            y_start += board_square_size
            self.horizontal_lines.append(Area(x_start,y_start,board_lines_size2,board_lines_size,self.linesColor))
        self.player = []
        self.player.append(Player('player1/front.png', 'player1/front2.png', 'dog1/walking.png', 'dog1/jumping.png','playersign/1.png', 'bubble/1.png','bubble/2.png','bubble/3.png','bubble/4.png', 'bubble/5.png', x=0, y=600, x2=50,y2=750))
        self.player.append(Player('player2/front.png', 'player2/front2.png', 'dog2/walking.png', 'dog2/jumping.png','playersign/2.png', 'bubble/1.png','bubble/2.png','bubble/3.png','bubble/4.png', 'bubble/5.png', x=550, y=600, x2=450,y2=750))
        #self.player1 = Player('player2/front.png', 'player2/front2.png', 'dog2/walking.png', 'dog2/jumping.png','playersign/2.png', 'bubble/1.png','bubble/2.png','bubble/3.png','bubble/4.png', 'bubble/5.png', x=550, y=600, x2=450,y2=750)            
        

    def run(self):
        game_over = False
        isPlayer1 = True
        self.player[0].isDog = False
        self.player[0].expandBubble = False
        self.player[0].isDog = False
        self.player[0].isPlayer = True
        self.player[1].isDog = False
        self.player[1].isPlayer = False
        self.player[1].expandBubble = False
        move_right_p1 = False
        move_left_p1 = False
        move_dog_rght = False #move dog1 right
        move_dof_lft = False #move dog2 left
        move_dog_up = False
        currPlyr = 0
        #isPlayer2 = False
        while not game_over:
            isPlayer1Tk = False
            isPlayer2Tk = False
            self.screen.fill(self.back)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    game_over = True
                    pygame.quit()
                    sys.exit()
                if (not self.player[currPlyr].isDog) and self.player[currPlyr].isPlayer:
                    if self.player[currPlyr].currBubble >= 4:
                        #isPlayer1 = False
                        self.player[currPlyr].expandBubble = False
                        self.player[currPlyr].currMan = 0
                        if currPlyr == 0:
                            self.player[currPlyr].isPlayer = False
                            currPlyr = 1
                            self.player[currPlyr].isPlayer = True
                        elif currPlyr == 1:
                            self.player[currPlyr].isPlayer = False
                            currPlyr = 0
                            self.player[currPlyr].isPlayer = True
                        self.player[currPlyr].currBubble = 0
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            if self.player[currPlyr].isDog:
                                self.player[currPlyr].isDog = False
                                self.player[currPlyr].isPlayer =True
                            else:
                                self.player[currPlyr].isDog = True
                                self.player[currPlyr].isPlayer = False
                        if (not self.player[currPlyr].isDog) and self.player[currPlyr].isPlayer:
                            if event.key == pygame.K_RIGHT:
                                move_right_p1 = True
                            if event.key == pygame.K_LEFT:
                                move_left_p1 = True
                            if event.key == pygame.K_UP:
                                self.player[currPlyr].expandBubble = True
                                self.player[currPlyr].currMan = 1
                    elif event.type == pygame.KEYUP:
                        if event.key == pygame.K_RIGHT:
                            move_right_p1 = False
                        if event.key == pygame.K_LEFT:
                            move_left_p1 = False
                        if event.key == pygame.K_UP:
                            self.player[currPlyr].expandBubble = False
                            self.player[currPlyr].currMan = 0
                            if self.player[currPlyr].currBubble > 0 and self.player[currPlyr].currBubble < 4:
                                self.player[currPlyr].isDog = True
                                self.player[currPlyr].isFloating = True
                                self.player[currPlyr].floatinngBubble = self.player[currPlyr].currBubble
                                self.player[currPlyr].floatinngBubbleRect.x = self.player[currPlyr].bubblesManRectExpsn.x
                                self.player[currPlyr].floatinngBubbleRect.y = self.player[currPlyr].bubblesManRectExpsn.y
                                self.player[currPlyr].floatinngBubbleRect.width = self.player[currPlyr].bubblesManRectExpsn.width
                                self.player[currPlyr].floatinngBubbleRect.height = self.player[currPlyr].bubblesManRectExpsn.height
                                self.player[currPlyr].currBubble = 0
                            #self.player1.bubbleExpansion(self.screen)
                else:
                    move_right_p1 = False
                    move_left_p1 = False
                if self.player[currPlyr].isDog and (not self.player[currPlyr].isPlayer):
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            if self.player[currPlyr].isDog:
                                self.player[currPlyr].isDog = False
                                self.player[currPlyr].isPlayer =True
                            else:
                                self.player[currPlyr].isDog = True
                                self.player[currPlyr].isPlayer = False
                        if event.key == pygame.K_RIGHT:
                            move_dog_rght = True
                        if event.key == pygame.K_LEFT:
                            move_dof_lft = True
                        if event.key == pygame.K_UP:
                            move_dog_up = True
                    elif event.type == pygame.KEYUP:
                        if event.key == pygame.K_RIGHT:
                            move_dog_rght = False
                        if event.key == pygame.K_LEFT:
                            move_dof_lft = False
                        if event.key == pygame.K_UP:
                            move_dog_up = False
                            #self.player1.bubbleExpansion(self.screen)
                else:
                    move_dog_rght = False #move dog1 right
                    move_dof_lft = False #move dog2 left 
                    move_dog_up = False
            if move_right_p1:
                self.player[currPlyr].moveManRight()
            if move_left_p1:
                self.player[currPlyr].moveManLeft()
            if move_dog_rght:
                self.player[currPlyr].moveDogRight()
            if move_dof_lft:
                self.player[currPlyr].moveDogLeft()
            if move_dog_up:
                self.player[currPlyr].moveDogUp()
            else:
                self.player[currPlyr].dogFalling()
                
            #if expandBubble1:
            #    self.player1.currMan = 1
            #    self.player1.bubbleExpansion(self.screen)
            for b in self.board:
                for bd in b:
                    #print(bd.rect.x)
                    bd.fill(self.screen)
            for h in self.horizontal_lines:
                h.fill(self.screen)
            for v in self.vertical_lines:
                v.fill(self.screen)
            #self.token1.draw(self.screen,0,0)
            #for tok1 in self.tokens_player2:
            #    for tk in tok1:
            #        tk.draw(self.screen)
            self.player[0].drawMan(self.screen)
            self.player[1].drawMan(self.screen)
            self.player[0].drawDog(self.screen)
            self.player[1].drawDog(self.screen)
            #self.player1.drawBubbleFloating(self.screen)
            #if self.player1.expandBubble:
            #    self.player1.bubbleExpansion(self.screen)
            #else:
            #    self.player1.currMan = 0
            #for event in pygame.event.get():
            #    if event.type == pygame.QUIT:
            #        game_over = True
            #        pygame.quit()
            #        sys.exit()
            pygame.display.update()
            self.clock.tick(15)
Game().run()